//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_ENGINE_H
#define EVOSCRIPTLIB_ENGINE_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Types/SharedPtr.h"
#include "Libraries/Window.h"

class Scene;
class Render;
class Camera;

class Engine;

typedef void Time;
typedef void PhysEngine;

typedef std::function<Engine&()> EngineInstanceFnPtr;
EngineInstanceFnPtr g_EngineInstanceFnPtr;
EXTERN void EngineInstanceFnPtrSetter(const std::function<Engine&()>& fnPtr) { 
	g_EngineInstanceFnPtr = fnPtr; 
}

typedef std::function<Window*(Engine*)> EngineGetMainWindowFnPtr;
EngineGetMainWindowFnPtr g_EngineGetMainWindowFnPtr;
EXTERN void EngineGetMainWindowFnPtrSetter(const std::function<Window*(Engine*)>& fnPtr) { 
	g_EngineGetMainWindowFnPtr = fnPtr; 
}

typedef std::function<uint32_t(Engine*)> EngineGetFramesPerSecondFnPtr;
EngineGetFramesPerSecondFnPtr g_EngineGetFramesPerSecondFnPtr;
EXTERN void EngineGetFramesPerSecondFnPtrSetter(const std::function<uint32_t(Engine*)>& fnPtr) { 
	g_EngineGetFramesPerSecondFnPtr = fnPtr; 
}

class Engine {
public:
	Engine() = delete;
	~Engine() = default;
	Engine(Engine &) = delete;
	Engine(const Engine &) = delete;
public:
	static Engine& Instance() {
		return g_EngineInstanceFnPtr();
	}
	Window* GetMainWindow() {
		return g_EngineGetMainWindowFnPtr(this);
	}
	uint32_t GetFramesPerSecond() {
		return g_EngineGetFramesPerSecondFnPtr(this);
	}
};

#endif