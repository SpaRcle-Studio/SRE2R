//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_ISAVABLE_H
#define EVOSCRIPTLIB_ISAVABLE_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

class Document;
class ISavable;

class Document {
public:
	Document() = delete;
	~Document() = default;
	Document(Document &) = delete;
	Document(const Document &) = delete;
};

class ISavable {
public:
	ISavable() = delete;
	~ISavable() = default;
	ISavable(ISavable &) = delete;
	ISavable(const ISavable &) = delete;
};

#endif