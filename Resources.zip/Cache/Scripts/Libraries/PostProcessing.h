//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_POSTPROCESSING_H
#define EVOSCRIPTLIB_POSTPROCESSING_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/Vector3.h"
#include "cstdint"
#include "vector"

class Shader;
class Camera;
class Render;

class PostProcessing;

class PostProcessing {
public:
	PostProcessing() = delete;
	~PostProcessing() = default;
	PostProcessing(PostProcessing &) = delete;
	PostProcessing(const PostProcessing &) = delete;
};

#endif