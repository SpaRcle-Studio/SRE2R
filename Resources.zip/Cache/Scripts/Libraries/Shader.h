//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_SHADER_H
#define EVOSCRIPTLIB_SHADER_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

class Shader;

class Shader {
public:
	Shader() = delete;
	~Shader() = default;
	Shader(Shader &) = delete;
	Shader(const Shader &) = delete;
};

#endif