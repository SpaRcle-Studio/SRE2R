//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_CAMERA_H
#define EVOSCRIPTLIB_CAMERA_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/Math/Vector2.h"
#include "Libraries/Math/Vector3.h"

class Camera;

class Camera : public Component {
public:
	Camera() = delete;
	~Camera() = default;
	Camera(Camera &) = delete;
	Camera(const Camera &) = delete;
};

#endif