//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_TEXT_H
#define EVOSCRIPTLIB_TEXT_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/Mesh.h"

class Text2D;
class Text3D;

typedef std::function<void(Text2D*, const std::string& text)> Text2DSetTextFnPtr;
Text2DSetTextFnPtr g_Text2DSetTextFnPtr;
EXTERN void Text2DSetTextFnPtrSetter(const std::function<void(Text2D*, const std::string& text)>& fnPtr) { 
	g_Text2DSetTextFnPtr = fnPtr; 
}

typedef std::function<void(Text3D*, const std::string& text)> Text3DSetTextFnPtr;
Text3DSetTextFnPtr g_Text3DSetTextFnPtr;
EXTERN void Text3DSetTextFnPtrSetter(const std::function<void(Text3D*, const std::string& text)>& fnPtr) { 
	g_Text3DSetTextFnPtr = fnPtr; 
}

class Text2D : public Component, public Mesh {
public:
	Text2D() = delete;
	~Text2D() = default;
	Text2D(Text2D &) = delete;
	Text2D(const Text2D &) = delete;
public:
	void SetText(const std::string& text) {
		return g_Text2DSetTextFnPtr(this, text);
	}
};

class Text3D : public Component, public Mesh {
public:
	Text3D() = delete;
	~Text3D() = default;
	Text3D(Text3D &) = delete;
	Text3D(const Text3D &) = delete;
public:
	void SetText(const std::string& text) {
		return g_Text3DSetTextFnPtr(this, text);
	}
};

#endif