//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_CASTS_H
#define EVOSCRIPTLIB_CASTS_H

#ifndef EXTERN
	#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

class Component;
class ProceduralMesh;
class Rigidbody;
class Rigidbody3D;
class SceneCubeChunkLogic;
class SceneLogic;
class Text2D;
class Text3D;

typedef std::function<Component*(ProceduralMesh* from)> DynamicCastProceduralMeshToComponentFnPtr;
DynamicCastProceduralMeshToComponentFnPtr g_DynamicCastProceduralMeshToComponentFnPtr;
EXTERN void DynamicCastProceduralMeshToComponentFnPtrSetter(const std::function<Component*(ProceduralMesh* from)>& fnPtr) { 
	g_DynamicCastProceduralMeshToComponentFnPtr = fnPtr; 
}

static Component* DynamicCastProceduralMeshToComponent(ProceduralMesh* from) {
	return g_DynamicCastProceduralMeshToComponentFnPtr(from);
}

typedef std::function<ProceduralMesh*(Component* from)> DynamicCastComponentToProceduralMeshFnPtr;
DynamicCastComponentToProceduralMeshFnPtr g_DynamicCastComponentToProceduralMeshFnPtr;
EXTERN void DynamicCastComponentToProceduralMeshFnPtrSetter(const std::function<ProceduralMesh*(Component* from)>& fnPtr) { 
	g_DynamicCastComponentToProceduralMeshFnPtr = fnPtr; 
}

static ProceduralMesh* DynamicCastComponentToProceduralMesh(Component* from) {
	return g_DynamicCastComponentToProceduralMeshFnPtr(from);
}

typedef std::function<Component*(Rigidbody3D* from)> DynamicCastRigidbody3DToComponentFnPtr;
DynamicCastRigidbody3DToComponentFnPtr g_DynamicCastRigidbody3DToComponentFnPtr;
EXTERN void DynamicCastRigidbody3DToComponentFnPtrSetter(const std::function<Component*(Rigidbody3D* from)>& fnPtr) { 
	g_DynamicCastRigidbody3DToComponentFnPtr = fnPtr; 
}

static Component* DynamicCastRigidbody3DToComponent(Rigidbody3D* from) {
	return g_DynamicCastRigidbody3DToComponentFnPtr(from);
}

typedef std::function<Rigidbody3D*(Component* from)> DynamicCastComponentToRigidbody3DFnPtr;
DynamicCastComponentToRigidbody3DFnPtr g_DynamicCastComponentToRigidbody3DFnPtr;
EXTERN void DynamicCastComponentToRigidbody3DFnPtrSetter(const std::function<Rigidbody3D*(Component* from)>& fnPtr) { 
	g_DynamicCastComponentToRigidbody3DFnPtr = fnPtr; 
}

static Rigidbody3D* DynamicCastComponentToRigidbody3D(Component* from) {
	return g_DynamicCastComponentToRigidbody3DFnPtr(from);
}

typedef std::function<Component*(Rigidbody* from)> DynamicCastRigidbodyToComponentFnPtr;
DynamicCastRigidbodyToComponentFnPtr g_DynamicCastRigidbodyToComponentFnPtr;
EXTERN void DynamicCastRigidbodyToComponentFnPtrSetter(const std::function<Component*(Rigidbody* from)>& fnPtr) { 
	g_DynamicCastRigidbodyToComponentFnPtr = fnPtr; 
}

static Component* DynamicCastRigidbodyToComponent(Rigidbody* from) {
	return g_DynamicCastRigidbodyToComponentFnPtr(from);
}

typedef std::function<Rigidbody*(Component* from)> DynamicCastComponentToRigidbodyFnPtr;
DynamicCastComponentToRigidbodyFnPtr g_DynamicCastComponentToRigidbodyFnPtr;
EXTERN void DynamicCastComponentToRigidbodyFnPtrSetter(const std::function<Rigidbody*(Component* from)>& fnPtr) { 
	g_DynamicCastComponentToRigidbodyFnPtr = fnPtr; 
}

static Rigidbody* DynamicCastComponentToRigidbody(Component* from) {
	return g_DynamicCastComponentToRigidbodyFnPtr(from);
}

typedef std::function<Component*(Text2D* from)> DynamicCastText2DToComponentFnPtr;
DynamicCastText2DToComponentFnPtr g_DynamicCastText2DToComponentFnPtr;
EXTERN void DynamicCastText2DToComponentFnPtrSetter(const std::function<Component*(Text2D* from)>& fnPtr) { 
	g_DynamicCastText2DToComponentFnPtr = fnPtr; 
}

static Component* DynamicCastText2DToComponent(Text2D* from) {
	return g_DynamicCastText2DToComponentFnPtr(from);
}

typedef std::function<Text2D*(Component* from)> DynamicCastComponentToText2DFnPtr;
DynamicCastComponentToText2DFnPtr g_DynamicCastComponentToText2DFnPtr;
EXTERN void DynamicCastComponentToText2DFnPtrSetter(const std::function<Text2D*(Component* from)>& fnPtr) { 
	g_DynamicCastComponentToText2DFnPtr = fnPtr; 
}

static Text2D* DynamicCastComponentToText2D(Component* from) {
	return g_DynamicCastComponentToText2DFnPtr(from);
}

typedef std::function<Component*(Text3D* from)> DynamicCastText3DToComponentFnPtr;
DynamicCastText3DToComponentFnPtr g_DynamicCastText3DToComponentFnPtr;
EXTERN void DynamicCastText3DToComponentFnPtrSetter(const std::function<Component*(Text3D* from)>& fnPtr) { 
	g_DynamicCastText3DToComponentFnPtr = fnPtr; 
}

static Component* DynamicCastText3DToComponent(Text3D* from) {
	return g_DynamicCastText3DToComponentFnPtr(from);
}

typedef std::function<Text3D*(Component* from)> DynamicCastComponentToText3DFnPtr;
DynamicCastComponentToText3DFnPtr g_DynamicCastComponentToText3DFnPtr;
EXTERN void DynamicCastComponentToText3DFnPtrSetter(const std::function<Text3D*(Component* from)>& fnPtr) { 
	g_DynamicCastComponentToText3DFnPtr = fnPtr; 
}

static Text3D* DynamicCastComponentToText3D(Component* from) {
	return g_DynamicCastComponentToText3DFnPtr(from);
}

typedef std::function<SceneCubeChunkLogic*(SceneLogic* from)> DynamicCastSceneLogicToSceneCubeChunkLogicFnPtr;
DynamicCastSceneLogicToSceneCubeChunkLogicFnPtr g_DynamicCastSceneLogicToSceneCubeChunkLogicFnPtr;
EXTERN void DynamicCastSceneLogicToSceneCubeChunkLogicFnPtrSetter(const std::function<SceneCubeChunkLogic*(SceneLogic* from)>& fnPtr) { 
	g_DynamicCastSceneLogicToSceneCubeChunkLogicFnPtr = fnPtr; 
}

static SceneCubeChunkLogic* DynamicCastSceneLogicToSceneCubeChunkLogic(SceneLogic* from) {
	return g_DynamicCastSceneLogicToSceneCubeChunkLogicFnPtr(from);
}

typedef std::function<SceneLogic*(SceneCubeChunkLogic* from)> DynamicCastSceneCubeChunkLogicToSceneLogicFnPtr;
DynamicCastSceneCubeChunkLogicToSceneLogicFnPtr g_DynamicCastSceneCubeChunkLogicToSceneLogicFnPtr;
EXTERN void DynamicCastSceneCubeChunkLogicToSceneLogicFnPtrSetter(const std::function<SceneLogic*(SceneCubeChunkLogic* from)>& fnPtr) { 
	g_DynamicCastSceneCubeChunkLogicToSceneLogicFnPtr = fnPtr; 
}

static SceneLogic* DynamicCastSceneCubeChunkLogicToSceneLogic(SceneCubeChunkLogic* from) {
	return g_DynamicCastSceneCubeChunkLogicToSceneLogicFnPtr(from);
}

#endif // EVOSCRIPTLIB_CASTS_H