//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_COMPONENT_H
#define EVOSCRIPTLIB_COMPONENT_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/Vector3.h"
#include "string"

class GameObject;

class Component;

typedef std::function<std::string(Component*)> ComponentGetComponentNameFnPtr;
ComponentGetComponentNameFnPtr g_ComponentGetComponentNameFnPtr;
EXTERN void ComponentGetComponentNameFnPtrSetter(const std::function<std::string(Component*)>& fnPtr) { 
	g_ComponentGetComponentNameFnPtr = fnPtr; 
}

typedef std::function<Component*(Component*)> ComponentBaseComponentFnPtr;
ComponentBaseComponentFnPtr g_ComponentBaseComponentFnPtr;
EXTERN void ComponentBaseComponentFnPtrSetter(const std::function<Component*(Component*)>& fnPtr) { 
	g_ComponentBaseComponentFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(Component*)> ComponentGetGameObjectFnPtr;
ComponentGetGameObjectFnPtr g_ComponentGetGameObjectFnPtr;
EXTERN void ComponentGetGameObjectFnPtrSetter(const std::function<SharedPtr<GameObject>(Component*)>& fnPtr) { 
	g_ComponentGetGameObjectFnPtr = fnPtr; 
}

typedef std::function<FVector3(Component*)> ComponentGetBarycenterFnPtr;
ComponentGetBarycenterFnPtr g_ComponentGetBarycenterFnPtr;
EXTERN void ComponentGetBarycenterFnPtrSetter(const std::function<FVector3(Component*)>& fnPtr) { 
	g_ComponentGetBarycenterFnPtr = fnPtr; 
}

typedef std::function<bool(Component*)> ComponentIsActiveFnPtr;
ComponentIsActiveFnPtr g_ComponentIsActiveFnPtr;
EXTERN void ComponentIsActiveFnPtrSetter(const std::function<bool(Component*)>& fnPtr) { 
	g_ComponentIsActiveFnPtr = fnPtr; 
}

typedef std::function<void(Component*, bool v)> ComponentSetEnabledFnPtr;
ComponentSetEnabledFnPtr g_ComponentSetEnabledFnPtr;
EXTERN void ComponentSetEnabledFnPtrSetter(const std::function<void(Component*, bool v)>& fnPtr) { 
	g_ComponentSetEnabledFnPtr = fnPtr; 
}

typedef std::function<Component*(const std::string& name)> ComponentCreateFnPtr;
ComponentCreateFnPtr g_ComponentCreateFnPtr;
EXTERN void ComponentCreateFnPtrSetter(const std::function<Component*(const std::string& name)>& fnPtr) { 
	g_ComponentCreateFnPtr = fnPtr; 
}

class Component {
public:
	Component() = delete;
	~Component() = default;
	Component(Component &) = delete;
	Component(const Component &) = delete;
public:
	std::string GetComponentName() {
		return g_ComponentGetComponentNameFnPtr(this);
	}
	Component* BaseComponent() {
		return g_ComponentBaseComponentFnPtr(this);
	}
	SharedPtr<GameObject> GetGameObject() {
		return g_ComponentGetGameObjectFnPtr(this);
	}
	FVector3 GetBarycenter() {
		return g_ComponentGetBarycenterFnPtr(this);
	}
	bool IsActive() {
		return g_ComponentIsActiveFnPtr(this);
	}
	void SetEnabled(bool v) {
		return g_ComponentSetEnabledFnPtr(this, v);
	}
	static Component* Create(const std::string& name) {
		return g_ComponentCreateFnPtr(name);
	}
};

#endif