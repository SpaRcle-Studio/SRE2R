//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_MATERIAL_H
#define EVOSCRIPTLIB_MATERIAL_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Texture.h"

class Mesh;

class Material;

class Material {
public:
	Material() = delete;
	~Material() = default;
	Material(Material &) = delete;
	Material(const Material &) = delete;
};

#endif