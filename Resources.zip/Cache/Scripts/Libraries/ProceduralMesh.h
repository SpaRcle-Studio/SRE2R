//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_PROCEDURALMESH_H
#define EVOSCRIPTLIB_PROCEDURALMESH_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/Material.h"
#include "Libraries/Math/Vector3.h"
#include "Libraries/Math/Vertices.h"
#include "Libraries/ResourceManager.h"

class ProceduralMesh;

typedef std::function<void(ProceduralMesh*, Material* material)> ProceduralMeshSetMaterialFnPtr;
ProceduralMeshSetMaterialFnPtr g_ProceduralMeshSetMaterialFnPtr;
EXTERN void ProceduralMeshSetMaterialFnPtrSetter(const std::function<void(ProceduralMesh*, Material* material)>& fnPtr) { 
	g_ProceduralMeshSetMaterialFnPtr = fnPtr; 
}

typedef std::function<std::string(ProceduralMesh*)> ProceduralMeshGetGeometryNameFnPtr;
ProceduralMeshGetGeometryNameFnPtr g_ProceduralMeshGetGeometryNameFnPtr;
EXTERN void ProceduralMeshGetGeometryNameFnPtrSetter(const std::function<std::string(ProceduralMesh*)>& fnPtr) { 
	g_ProceduralMeshGetGeometryNameFnPtr = fnPtr; 
}

typedef std::function<Material*(ProceduralMesh*)> ProceduralMeshGetMaterialFnPtr;
ProceduralMeshGetMaterialFnPtr g_ProceduralMeshGetMaterialFnPtr;
EXTERN void ProceduralMeshGetMaterialFnPtrSetter(const std::function<Material*(ProceduralMesh*)>& fnPtr) { 
	g_ProceduralMeshGetMaterialFnPtr = fnPtr; 
}

typedef std::function<void(ProceduralMesh*, const std::vector<StaticMeshVertex>& vertices)> ProceduralMeshSetVerticesFnPtr;
ProceduralMeshSetVerticesFnPtr g_ProceduralMeshSetVerticesFnPtr;
EXTERN void ProceduralMeshSetVerticesFnPtrSetter(const std::function<void(ProceduralMesh*, const std::vector<StaticMeshVertex>& vertices)>& fnPtr) { 
	g_ProceduralMeshSetVerticesFnPtr = fnPtr; 
}

typedef std::function<void(ProceduralMesh*, void* pData, uint64_t count)> ProceduralMeshSetIndexedVerticesFnPtr;
ProceduralMeshSetIndexedVerticesFnPtr g_ProceduralMeshSetIndexedVerticesFnPtr;
EXTERN void ProceduralMeshSetIndexedVerticesFnPtrSetter(const std::function<void(ProceduralMesh*, void* pData, uint64_t count)>& fnPtr) { 
	g_ProceduralMeshSetIndexedVerticesFnPtr = fnPtr; 
}

typedef std::function<void(ProceduralMesh*, void* pData, uint64_t count)> ProceduralMeshSetIndicesFnPtr;
ProceduralMeshSetIndicesFnPtr g_ProceduralMeshSetIndicesFnPtr;
EXTERN void ProceduralMeshSetIndicesFnPtrSetter(const std::function<void(ProceduralMesh*, void* pData, uint64_t count)>& fnPtr) { 
	g_ProceduralMeshSetIndicesFnPtr = fnPtr; 
}

class ProceduralMesh : public IResource, public Component {
public:
	ProceduralMesh() = delete;
	~ProceduralMesh() = default;
	ProceduralMesh(ProceduralMesh &) = delete;
	ProceduralMesh(const ProceduralMesh &) = delete;
public:
	void SetMaterial(Material* material) {
		return g_ProceduralMeshSetMaterialFnPtr(this, material);
	}
	std::string GetGeometryName() {
		return g_ProceduralMeshGetGeometryNameFnPtr(this);
	}
	Material* GetMaterial() {
		return g_ProceduralMeshGetMaterialFnPtr(this);
	}
	void SetVertices(const std::vector<StaticMeshVertex>& vertices) {
		return g_ProceduralMeshSetVerticesFnPtr(this, vertices);
	}
	void SetIndexedVertices(void* pData, uint64_t count) {
		return g_ProceduralMeshSetIndexedVerticesFnPtr(this, pData, count);
	}
	void SetIndices(void* pData, uint64_t count) {
		return g_ProceduralMeshSetIndicesFnPtr(this, pData, count);
	}
};

#endif