//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_RAYCAST_H
#define EVOSCRIPTLIB_RAYCAST_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "string"

class Raycast3D;

typedef std::function<std::vector<RaycastHit>(const FVector3& origin, const FVector3& direction, float_t maxDistance, uint32_t maxHits)> Raycast3DCastFnPtr;
Raycast3DCastFnPtr g_Raycast3DCastFnPtr;
EXTERN void Raycast3DCastFnPtrSetter(const std::function<std::vector<RaycastHit>(const FVector3& origin, const FVector3& direction, float_t maxDistance, uint32_t maxHits)>& fnPtr) { 
	g_Raycast3DCastFnPtr = fnPtr; 
}

class Raycast3D {
public:
	Raycast3D() = delete;
	~Raycast3D() = default;
	Raycast3D(Raycast3D &) = delete;
	Raycast3D(const Raycast3D &) = delete;
public:
	static std::vector<RaycastHit> Cast(const FVector3& origin, const FVector3& direction, float_t maxDistance, uint32_t maxHits) {
		return g_Raycast3DCastFnPtr(origin, direction, maxDistance, maxHits);
	}
};

#endif