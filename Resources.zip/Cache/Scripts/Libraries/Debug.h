//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_DEBUG_H
#define EVOSCRIPTLIB_DEBUG_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "string"

class Debug;

typedef std::function<void(const std::string& msg)> DebugLogFnPtr;
DebugLogFnPtr g_DebugLogFnPtr;
EXTERN void DebugLogFnPtrSetter(const std::function<void(const std::string& msg)>& fnPtr) { 
	g_DebugLogFnPtr = fnPtr; 
}

typedef std::function<void(const std::string& msg)> DebugErrorFnPtr;
DebugErrorFnPtr g_DebugErrorFnPtr;
EXTERN void DebugErrorFnPtrSetter(const std::function<void(const std::string& msg)>& fnPtr) { 
	g_DebugErrorFnPtr = fnPtr; 
}

typedef std::function<void(const std::string& msg)> DebugWarnFnPtr;
DebugWarnFnPtr g_DebugWarnFnPtr;
EXTERN void DebugWarnFnPtrSetter(const std::function<void(const std::string& msg)>& fnPtr) { 
	g_DebugWarnFnPtr = fnPtr; 
}

typedef std::function<void(const std::string& msg)> DebugHaltFnPtr;
DebugHaltFnPtr g_DebugHaltFnPtr;
EXTERN void DebugHaltFnPtrSetter(const std::function<void(const std::string& msg)>& fnPtr) { 
	g_DebugHaltFnPtr = fnPtr; 
}

class Debug {
public:
	Debug() = delete;
	~Debug() = default;
	Debug(Debug &) = delete;
	Debug(const Debug &) = delete;
public:
	static void Log(const std::string& msg) {
		return g_DebugLogFnPtr(msg);
	}
	static void Error(const std::string& msg) {
		return g_DebugErrorFnPtr(msg);
	}
	static void Warn(const std::string& msg) {
		return g_DebugWarnFnPtr(msg);
	}
	static void Halt(const std::string& msg) {
		return g_DebugHaltFnPtr(msg);
	}
};

#endif