//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_MESH_H
#define EVOSCRIPTLIB_MESH_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/Material.h"
#include "Libraries/Math/Vector3.h"
#include "Libraries/ResourceManager.h"

enum class MeshType {
	Unknown = 0, Static = 1, Wireframe = 2, Skinned = 3, Sprite = 4, Procedural = 5, 
};

class Mesh;

class Mesh;

typedef std::function<std::vector<Mesh*>(const std::string& path, MeshType type)> MeshLoadFnPtr;
MeshLoadFnPtr g_MeshLoadFnPtr;
EXTERN void MeshLoadFnPtrSetter(const std::function<std::vector<Mesh*>(const std::string& path, MeshType type)>& fnPtr) { 
	g_MeshLoadFnPtr = fnPtr; 
}

typedef std::function<void(Mesh*, Material* material)> MeshSetMaterialFnPtr;
MeshSetMaterialFnPtr g_MeshSetMaterialFnPtr;
EXTERN void MeshSetMaterialFnPtrSetter(const std::function<void(Mesh*, Material* material)>& fnPtr) { 
	g_MeshSetMaterialFnPtr = fnPtr; 
}

typedef std::function<std::string(Mesh*)> MeshGetGeometryNameFnPtr;
MeshGetGeometryNameFnPtr g_MeshGetGeometryNameFnPtr;
EXTERN void MeshGetGeometryNameFnPtrSetter(const std::function<std::string(Mesh*)>& fnPtr) { 
	g_MeshGetGeometryNameFnPtr = fnPtr; 
}

typedef std::function<Material*(Mesh*)> MeshGetMaterialFnPtr;
MeshGetMaterialFnPtr g_MeshGetMaterialFnPtr;
EXTERN void MeshGetMaterialFnPtrSetter(const std::function<Material*(Mesh*)>& fnPtr) { 
	g_MeshGetMaterialFnPtr = fnPtr; 
}

class Mesh {
public:
	Mesh() = delete;
	~Mesh() = default;
	Mesh(Mesh &) = delete;
	Mesh(const Mesh &) = delete;
public:
	static std::vector<Mesh*> Load(const std::string& path, MeshType type) {
		return g_MeshLoadFnPtr(path, type);
	}
	void SetMaterial(Material* material) {
		return g_MeshSetMaterialFnPtr(this, material);
	}
	std::string GetGeometryName() {
		return g_MeshGetGeometryNameFnPtr(this);
	}
	Material* GetMaterial() {
		return g_MeshGetMaterialFnPtr(this);
	}
};

#endif