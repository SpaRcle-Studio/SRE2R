//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_MATHF_H
#define EVOSCRIPTLIB_MATHF_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/CoreMath.h"
#include "Libraries/Math/Vector2.h"
#include "Libraries/Math/Vector3.h"

class Mathf;

typedef std::function<double_t(double_t x, double_t y)> MathfSNoise2DFnPtr;
MathfSNoise2DFnPtr g_MathfSNoise2DFnPtr;
EXTERN void MathfSNoise2DFnPtrSetter(const std::function<double_t(double_t x, double_t y)>& fnPtr) { 
	g_MathfSNoise2DFnPtr = fnPtr; 
}

typedef std::function<double_t(double_t x, double_t y, double_t z)> MathfSNoise3DFnPtr;
MathfSNoise3DFnPtr g_MathfSNoise3DFnPtr;
EXTERN void MathfSNoise3DFnPtrSetter(const std::function<double_t(double_t x, double_t y, double_t z)>& fnPtr) { 
	g_MathfSNoise3DFnPtr = fnPtr; 
}

typedef std::function<double_t(double_t x, double_t y, double_t z, double_t t)> MathfSNoise4DFnPtr;
MathfSNoise4DFnPtr g_MathfSNoise4DFnPtr;
EXTERN void MathfSNoise4DFnPtrSetter(const std::function<double_t(double_t x, double_t y, double_t z, double_t t)>& fnPtr) { 
	g_MathfSNoise4DFnPtr = fnPtr; 
}

class Mathf {
public:
	Mathf() = delete;
	~Mathf() = default;
	Mathf(Mathf &) = delete;
	Mathf(const Mathf &) = delete;
public:
	static double_t SNoise2D(double_t x, double_t y) {
		return g_MathfSNoise2DFnPtr(x, y);
	}
	static double_t SNoise3D(double_t x, double_t y, double_t z) {
		return g_MathfSNoise3DFnPtr(x, y, z);
	}
	static double_t SNoise4D(double_t x, double_t y, double_t z, double_t t) {
		return g_MathfSNoise4DFnPtr(x, y, z, t);
	}
};

#endif