//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_OBSERVER_H
#define EVOSCRIPTLIB_OBSERVER_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/Vector2.h"
#include "Libraries/Math/Vector3.h"

class Observer;

typedef std::function<IVector3(Observer*)> ObserverGetRegionFnPtr;
ObserverGetRegionFnPtr g_ObserverGetRegionFnPtr;
EXTERN void ObserverGetRegionFnPtrSetter(const std::function<IVector3(Observer*)>& fnPtr) { 
	g_ObserverGetRegionFnPtr = fnPtr; 
}

typedef std::function<IVector3(Observer*)> ObserverGetChunkFnPtr;
ObserverGetChunkFnPtr g_ObserverGetChunkFnPtr;
EXTERN void ObserverGetChunkFnPtrSetter(const std::function<IVector3(Observer*)>& fnPtr) { 
	g_ObserverGetChunkFnPtr = fnPtr; 
}

typedef std::function<IVector2(Observer*)> ObserverGetChunkSizeFnPtr;
ObserverGetChunkSizeFnPtr g_ObserverGetChunkSizeFnPtr;
EXTERN void ObserverGetChunkSizeFnPtrSetter(const std::function<IVector2(Observer*)>& fnPtr) { 
	g_ObserverGetChunkSizeFnPtr = fnPtr; 
}

typedef std::function<int32_t(Observer*)> ObserverGetRegionSizeFnPtr;
ObserverGetRegionSizeFnPtr g_ObserverGetRegionSizeFnPtr;
EXTERN void ObserverGetRegionSizeFnPtrSetter(const std::function<int32_t(Observer*)>& fnPtr) { 
	g_ObserverGetRegionSizeFnPtr = fnPtr; 
}

typedef std::function<int32_t(Observer*)> ObserverGetScopeFnPtr;
ObserverGetScopeFnPtr g_ObserverGetScopeFnPtr;
EXTERN void ObserverGetScopeFnPtrSetter(const std::function<int32_t(Observer*)>& fnPtr) { 
	g_ObserverGetScopeFnPtr = fnPtr; 
}

typedef std::function<bool(Observer*)> ObserverHasTargetFnPtr;
ObserverHasTargetFnPtr g_ObserverHasTargetFnPtr;
EXTERN void ObserverHasTargetFnPtrSetter(const std::function<bool(Observer*)>& fnPtr) { 
	g_ObserverHasTargetFnPtr = fnPtr; 
}

typedef std::function<ESMakePair(IVector3, IVector3)(Observer*, const IVector3& offset)> ObserverMathNeighbourFnPtr;
ObserverMathNeighbourFnPtr g_ObserverMathNeighbourFnPtr;
EXTERN void ObserverMathNeighbourFnPtrSetter(const std::function<ESMakePair(IVector3, IVector3)(Observer*, const IVector3& offset)>& fnPtr) { 
	g_ObserverMathNeighbourFnPtr = fnPtr; 
}

class Observer {
public:
	Observer() = delete;
	~Observer() = default;
	Observer(Observer &) = delete;
	Observer(const Observer &) = delete;
public:
	IVector3 GetRegion() {
		return g_ObserverGetRegionFnPtr(this);
	}
	IVector3 GetChunk() {
		return g_ObserverGetChunkFnPtr(this);
	}
	IVector2 GetChunkSize() {
		return g_ObserverGetChunkSizeFnPtr(this);
	}
	int32_t GetRegionSize() {
		return g_ObserverGetRegionSizeFnPtr(this);
	}
	int32_t GetScope() {
		return g_ObserverGetScopeFnPtr(this);
	}
	bool HasTarget() {
		return g_ObserverHasTargetFnPtr(this);
	}
	ESMakePair(IVector3, IVector3) MathNeighbour(const IVector3& offset) {
		return g_ObserverMathNeighbourFnPtr(this, offset);
	}
};

#endif