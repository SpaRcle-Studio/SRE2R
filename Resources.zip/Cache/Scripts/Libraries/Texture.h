//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_TEXTURE_H
#define EVOSCRIPTLIB_TEXTURE_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/ResourceManager.h"
#include "mutex"
#include "stdint.h"
#include "string"

enum class TextureCompression {
	None = 0, BC1 = 1, BC2 = 2, BC3 = 3, BC4 = 4, BC5 = 5, BC6 = 6, BC7 = 7, 
};

enum class ColorFormat {
	Unknown = 0, RGBA8_UNORM = 10000, RGBA16_UNORM = 10001, RGBA8_SRGB = 20000, 
};

enum class TextureType {
	Unknown = 0, Diffuse = 1, Normal = 2, Specular = 3, Roughness = 4, Glossiness = 5, 
};

enum class TextureFilter {
	Unknown = 0, NEAREST = 1, LINEAR = 2, 
};

class Texture;

class Texture : public IResource {
public:
	Texture() = delete;
	~Texture() = default;
	Texture(Texture &) = delete;
	Texture(const Texture &) = delete;
};

#endif