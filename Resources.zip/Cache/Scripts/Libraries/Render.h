//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_RENDER_H
#define EVOSCRIPTLIB_RENDER_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Shader.h"
#include "Libraries/Skybox.h"
#include "Libraries/Texture.h"
#include "map"
#include "mutex"
#include "stdint.h"
#include "vector"

class Window;
class Camera;
class Mesh;

class Render;

class Render {
public:
	Render() = delete;
	~Render() = default;
	Render(Render &) = delete;
	Render(const Render &) = delete;
};

#endif