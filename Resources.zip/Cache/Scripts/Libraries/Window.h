//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_WINDOW_H
#define EVOSCRIPTLIB_WINDOW_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/Vector2.h"
#include "mutex"
#include "stdint.h"
#include "thread"
#include "vector"

class Camera;
class Mesh;

class Window;

class Window {
public:
	Window() = delete;
	~Window() = default;
	Window(Window &) = delete;
	Window(const Window &) = delete;
};

#endif