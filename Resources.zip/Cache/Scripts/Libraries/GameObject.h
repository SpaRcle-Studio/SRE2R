//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_GAMEOBJECT_H
#define EVOSCRIPTLIB_GAMEOBJECT_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/ISavable.h"
#include "Libraries/Math/Vector3.h"
#include "Libraries/Transform.h"
#include "Libraries/Types/SafePointer.h"
#include "Libraries/Types/SharedPtr.h"
#include "mutex"
#include "string"
#include "vector"

class Scene;

class GameObject;

typedef std::function<bool(GameObject*, Component* comp)> GameObjectAddComponentFnPtr;
GameObjectAddComponentFnPtr g_GameObjectAddComponentFnPtr;
EXTERN void GameObjectAddComponentFnPtrSetter(const std::function<bool(GameObject*, Component* comp)>& fnPtr) { 
	g_GameObjectAddComponentFnPtr = fnPtr; 
}

typedef std::function<bool(GameObject*, const SharedPtr<GameObject>& child)> GameObjectAddChildFnPtr;
GameObjectAddChildFnPtr g_GameObjectAddChildFnPtr;
EXTERN void GameObjectAddChildFnPtrSetter(const std::function<bool(GameObject*, const SharedPtr<GameObject>& child)>& fnPtr) { 
	g_GameObjectAddChildFnPtr = fnPtr; 
}

typedef std::function<Component*(GameObject*, const std::string& name)> GameObjectGetComponentFnPtr;
GameObjectGetComponentFnPtr g_GameObjectGetComponentFnPtr;
EXTERN void GameObjectGetComponentFnPtrSetter(const std::function<Component*(GameObject*, const std::string& name)>& fnPtr) { 
	g_GameObjectGetComponentFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(GameObject*, const std::string& name)> GameObjectFindFnPtr;
GameObjectFindFnPtr g_GameObjectFindFnPtr;
EXTERN void GameObjectFindFnPtrSetter(const std::function<SharedPtr<GameObject>(GameObject*, const std::string& name)>& fnPtr) { 
	g_GameObjectFindFnPtr = fnPtr; 
}

typedef std::function<void(GameObject*, const std::string& name)> GameObjectSetNameFnPtr;
GameObjectSetNameFnPtr g_GameObjectSetNameFnPtr;
EXTERN void GameObjectSetNameFnPtrSetter(const std::function<void(GameObject*, const std::string& name)>& fnPtr) { 
	g_GameObjectSetNameFnPtr = fnPtr; 
}

typedef std::function<Component*(GameObject*, const std::string& name)> GameObjectGetOrCreateComponentFnPtr;
GameObjectGetOrCreateComponentFnPtr g_GameObjectGetOrCreateComponentFnPtr;
EXTERN void GameObjectGetOrCreateComponentFnPtrSetter(const std::function<Component*(GameObject*, const std::string& name)>& fnPtr) { 
	g_GameObjectGetOrCreateComponentFnPtr = fnPtr; 
}

typedef std::function<void(GameObject*, Transform* pTransform)> GameObjectSetTransformFnPtr;
GameObjectSetTransformFnPtr g_GameObjectSetTransformFnPtr;
EXTERN void GameObjectSetTransformFnPtrSetter(const std::function<void(GameObject*, Transform* pTransform)>& fnPtr) { 
	g_GameObjectSetTransformFnPtr = fnPtr; 
}

typedef std::function<FVector3(GameObject*)> GameObjectGetBarycenterFnPtr;
GameObjectGetBarycenterFnPtr g_GameObjectGetBarycenterFnPtr;
EXTERN void GameObjectGetBarycenterFnPtrSetter(const std::function<FVector3(GameObject*)>& fnPtr) { 
	g_GameObjectGetBarycenterFnPtr = fnPtr; 
}

typedef std::function<std::string(GameObject*)> GameObjectGetNameFnPtr;
GameObjectGetNameFnPtr g_GameObjectGetNameFnPtr;
EXTERN void GameObjectGetNameFnPtrSetter(const std::function<std::string(GameObject*)>& fnPtr) { 
	g_GameObjectGetNameFnPtr = fnPtr; 
}

typedef std::function<std::string(GameObject*)> GameObjectGetTagStringFnPtr;
GameObjectGetTagStringFnPtr g_GameObjectGetTagStringFnPtr;
EXTERN void GameObjectGetTagStringFnPtrSetter(const std::function<std::string(GameObject*)>& fnPtr) { 
	g_GameObjectGetTagStringFnPtr = fnPtr; 
}

typedef std::function<Transform*(GameObject*)> GameObjectGetTransformFnPtr;
GameObjectGetTransformFnPtr g_GameObjectGetTransformFnPtr;
EXTERN void GameObjectGetTransformFnPtrSetter(const std::function<Transform*(GameObject*)>& fnPtr) { 
	g_GameObjectGetTransformFnPtr = fnPtr; 
}

typedef std::function<Scene*(GameObject*)> GameObjectGetSceneFnPtr;
GameObjectGetSceneFnPtr g_GameObjectGetSceneFnPtr;
EXTERN void GameObjectGetSceneFnPtrSetter(const std::function<Scene*(GameObject*)>& fnPtr) { 
	g_GameObjectGetSceneFnPtr = fnPtr; 
}

typedef std::function<std::vector<SharedPtr<GameObject>>&(GameObject*)> GameObjectGetChildrenRefFnPtr;
GameObjectGetChildrenRefFnPtr g_GameObjectGetChildrenRefFnPtr;
EXTERN void GameObjectGetChildrenRefFnPtrSetter(const std::function<std::vector<SharedPtr<GameObject>>&(GameObject*)>& fnPtr) { 
	g_GameObjectGetChildrenRefFnPtr = fnPtr; 
}

class GameObject : public SharedPtr<GameObject> {
public:
	GameObject() = delete;
	~GameObject() = default;
	GameObject(GameObject &) = delete;
	GameObject(const GameObject &) = delete;
public:
	bool AddComponent(Component* comp) {
		return g_GameObjectAddComponentFnPtr(this, comp);
	}
	bool AddChild(const SharedPtr<GameObject>& child) {
		return g_GameObjectAddChildFnPtr(this, child);
	}
	Component* GetComponent(const std::string& name) {
		return g_GameObjectGetComponentFnPtr(this, name);
	}
	SharedPtr<GameObject> Find(const std::string& name) {
		return g_GameObjectFindFnPtr(this, name);
	}
	void SetName(const std::string& name) {
		return g_GameObjectSetNameFnPtr(this, name);
	}
	Component* GetOrCreateComponent(const std::string& name) {
		return g_GameObjectGetOrCreateComponentFnPtr(this, name);
	}
	void SetTransform(Transform* pTransform) {
		return g_GameObjectSetTransformFnPtr(this, pTransform);
	}
	FVector3 GetBarycenter() {
		return g_GameObjectGetBarycenterFnPtr(this);
	}
	std::string GetName() {
		return g_GameObjectGetNameFnPtr(this);
	}
	std::string GetTagString() {
		return g_GameObjectGetTagStringFnPtr(this);
	}
	Transform* GetTransform() {
		return g_GameObjectGetTransformFnPtr(this);
	}
	Scene* GetScene() {
		return g_GameObjectGetSceneFnPtr(this);
	}
	std::vector<SharedPtr<GameObject>>& GetChildrenRef() {
		return g_GameObjectGetChildrenRefFnPtr(this);
	}
};

#endif