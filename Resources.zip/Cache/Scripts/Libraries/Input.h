//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_INPUT_H
#define EVOSCRIPTLIB_INPUT_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/Vector2.h"

enum class MouseCode {
	MouseLeft = 1, MouseRight = 2, MouseMiddle = 4, 
};

enum class KeyCode {
	BackSpace = 8, Tab = 9, Enter = 13, LShift = 16, Ctrl = 17, Alt = 18, Esc = 27, Space = 32, LeftArrow = 37, UpArrow = 38, RightArrow = 39, DownArrow = 40, Del = 46, A = 65, B = 66, C = 67, D = 68, E = 69, F = 70, G = 71, H = 72, I = 73, J = 74, K = 75, L = 76, M = 77, N = 78, O = 79, P = 80, Q = 81, S = 83, R = 82, T = 84, U = 85, V = 86, W = 87, X = 88, Y = 89, Z = 90, F1 = 112, F2 = 113, F3 = 114, F4 = 115, F5 = 116, F6 = 117, F7 = 118, F8 = 119, F9 = 120, F10 = 121, F11 = 122, F12 = 123, 
};

class Input;

typedef std::function<bool(KeyCode key)> InputGetKeyFnPtr;
InputGetKeyFnPtr g_InputGetKeyFnPtr;
EXTERN void InputGetKeyFnPtrSetter(const std::function<bool(KeyCode key)>& fnPtr) { 
	g_InputGetKeyFnPtr = fnPtr; 
}

typedef std::function<void(bool lock)> InputLockCursorFnPtr;
InputLockCursorFnPtr g_InputLockCursorFnPtr;
EXTERN void InputLockCursorFnPtrSetter(const std::function<void(bool lock)>& fnPtr) { 
	g_InputLockCursorFnPtr = fnPtr; 
}

typedef std::function<bool(KeyCode key)> InputGetKeyDownFnPtr;
InputGetKeyDownFnPtr g_InputGetKeyDownFnPtr;
EXTERN void InputGetKeyDownFnPtrSetter(const std::function<bool(KeyCode key)>& fnPtr) { 
	g_InputGetKeyDownFnPtr = fnPtr; 
}

typedef std::function<bool(KeyCode key)> InputGetKeyUpFnPtr;
InputGetKeyUpFnPtr g_InputGetKeyUpFnPtr;
EXTERN void InputGetKeyUpFnPtrSetter(const std::function<bool(KeyCode key)>& fnPtr) { 
	g_InputGetKeyUpFnPtr = fnPtr; 
}

typedef std::function<bool(MouseCode key)> InputGetMouseDownFnPtr;
InputGetMouseDownFnPtr g_InputGetMouseDownFnPtr;
EXTERN void InputGetMouseDownFnPtrSetter(const std::function<bool(MouseCode key)>& fnPtr) { 
	g_InputGetMouseDownFnPtr = fnPtr; 
}

typedef std::function<bool(MouseCode key)> InputGetMouseFnPtr;
InputGetMouseFnPtr g_InputGetMouseFnPtr;
EXTERN void InputGetMouseFnPtrSetter(const std::function<bool(MouseCode key)>& fnPtr) { 
	g_InputGetMouseFnPtr = fnPtr; 
}

typedef std::function<bool(MouseCode key)> InputGetMouseUpFnPtr;
InputGetMouseUpFnPtr g_InputGetMouseUpFnPtr;
EXTERN void InputGetMouseUpFnPtrSetter(const std::function<bool(MouseCode key)>& fnPtr) { 
	g_InputGetMouseUpFnPtr = fnPtr; 
}

typedef std::function<FVector2()> InputGetMouseDragFnPtr;
InputGetMouseDragFnPtr g_InputGetMouseDragFnPtr;
EXTERN void InputGetMouseDragFnPtrSetter(const std::function<FVector2()>& fnPtr) { 
	g_InputGetMouseDragFnPtr = fnPtr; 
}

class Input {
public:
	Input() = delete;
	~Input() = default;
	Input(Input &) = delete;
	Input(const Input &) = delete;
public:
	static bool GetKey(KeyCode key) {
		return g_InputGetKeyFnPtr(key);
	}
	static void LockCursor(bool lock) {
		return g_InputLockCursorFnPtr(lock);
	}
	static bool GetKeyDown(KeyCode key) {
		return g_InputGetKeyDownFnPtr(key);
	}
	static bool GetKeyUp(KeyCode key) {
		return g_InputGetKeyUpFnPtr(key);
	}
	static bool GetMouseDown(MouseCode key) {
		return g_InputGetMouseDownFnPtr(key);
	}
	static bool GetMouse(MouseCode key) {
		return g_InputGetMouseFnPtr(key);
	}
	static bool GetMouseUp(MouseCode key) {
		return g_InputGetMouseUpFnPtr(key);
	}
	static FVector2 GetMouseDrag() {
		return g_InputGetMouseDragFnPtr();
	}
};

#endif