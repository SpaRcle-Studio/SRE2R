//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_TRANSFORM_H
#define EVOSCRIPTLIB_TRANSFORM_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Math/Vector2.h"
#include "Libraries/Math/Vector3.h"
#include "mutex"
#include "stdint.h"
#include "vector"

class Transform;

typedef std::function<void(Transform*, const FVector3& eulers)> TransformRotateFnPtr;
TransformRotateFnPtr g_TransformRotateFnPtr;
EXTERN void TransformRotateFnPtrSetter(const std::function<void(Transform*, const FVector3& eulers)>& fnPtr) { 
	g_TransformRotateFnPtr = fnPtr; 
}

typedef std::function<void(Transform*, const FVector3& eulers)> TransformGlobalRotateFnPtr;
TransformGlobalRotateFnPtr g_TransformGlobalRotateFnPtr;
EXTERN void TransformGlobalRotateFnPtrSetter(const std::function<void(Transform*, const FVector3& eulers)>& fnPtr) { 
	g_TransformGlobalRotateFnPtr = fnPtr; 
}

typedef std::function<void(Transform*, const FVector3& translation)> TransformTranslateFnPtr;
TransformTranslateFnPtr g_TransformTranslateFnPtr;
EXTERN void TransformTranslateFnPtrSetter(const std::function<void(Transform*, const FVector3& translation)>& fnPtr) { 
	g_TransformTranslateFnPtr = fnPtr; 
}

typedef std::function<void(Transform*, const FVector3& translation)> TransformSetTranslationFnPtr;
TransformSetTranslationFnPtr g_TransformSetTranslationFnPtr;
EXTERN void TransformSetTranslationFnPtrSetter(const std::function<void(Transform*, const FVector3& translation)>& fnPtr) { 
	g_TransformSetTranslationFnPtr = fnPtr; 
}

typedef std::function<void(Transform*, const FVector3& eulerAngles)> TransformSetRotationFnPtr;
TransformSetRotationFnPtr g_TransformSetRotationFnPtr;
EXTERN void TransformSetRotationFnPtrSetter(const std::function<void(Transform*, const FVector3& eulerAngles)>& fnPtr) { 
	g_TransformSetRotationFnPtr = fnPtr; 
}

typedef std::function<FVector3(Transform*)> TransformGetRotationFnPtr;
TransformGetRotationFnPtr g_TransformGetRotationFnPtr;
EXTERN void TransformGetRotationFnPtrSetter(const std::function<FVector3(Transform*)>& fnPtr) { 
	g_TransformGetRotationFnPtr = fnPtr; 
}

typedef std::function<FVector3(Transform*)> TransformGetTranslationFnPtr;
TransformGetTranslationFnPtr g_TransformGetTranslationFnPtr;
EXTERN void TransformGetTranslationFnPtrSetter(const std::function<FVector3(Transform*)>& fnPtr) { 
	g_TransformGetTranslationFnPtr = fnPtr; 
}

typedef std::function<Transform*()> TransformNewHolderFnPtr;
TransformNewHolderFnPtr g_TransformNewHolderFnPtr;
EXTERN void TransformNewHolderFnPtrSetter(const std::function<Transform*()>& fnPtr) { 
	g_TransformNewHolderFnPtr = fnPtr; 
}

typedef std::function<Transform*()> TransformNewZeroFnPtr;
TransformNewZeroFnPtr g_TransformNewZeroFnPtr;
EXTERN void TransformNewZeroFnPtrSetter(const std::function<Transform*()>& fnPtr) { 
	g_TransformNewZeroFnPtr = fnPtr; 
}

typedef std::function<Transform*()> TransformNew2DFnPtr;
TransformNew2DFnPtr g_TransformNew2DFnPtr;
EXTERN void TransformNew2DFnPtrSetter(const std::function<Transform*()>& fnPtr) { 
	g_TransformNew2DFnPtr = fnPtr; 
}

typedef std::function<Transform*()> TransformNew3DFnPtr;
TransformNew3DFnPtr g_TransformNew3DFnPtr;
EXTERN void TransformNew3DFnPtrSetter(const std::function<Transform*()>& fnPtr) { 
	g_TransformNew3DFnPtr = fnPtr; 
}

class Transform {
public:
	Transform() = delete;
	~Transform() = default;
	Transform(Transform &) = delete;
	Transform(const Transform &) = delete;
public:
	void Rotate(const FVector3& eulers) {
		return g_TransformRotateFnPtr(this, eulers);
	}
	void GlobalRotate(const FVector3& eulers) {
		return g_TransformGlobalRotateFnPtr(this, eulers);
	}
	void Translate(const FVector3& translation) {
		return g_TransformTranslateFnPtr(this, translation);
	}
	void SetTranslation(const FVector3& translation) {
		return g_TransformSetTranslationFnPtr(this, translation);
	}
	void SetRotation(const FVector3& eulerAngles) {
		return g_TransformSetRotationFnPtr(this, eulerAngles);
	}
	FVector3 GetRotation() {
		return g_TransformGetRotationFnPtr(this);
	}
	FVector3 GetTranslation() {
		return g_TransformGetTranslationFnPtr(this);
	}
	static Transform* NewHolder() {
		return g_TransformNewHolderFnPtr();
	}
	static Transform* NewZero() {
		return g_TransformNewZeroFnPtr();
	}
	static Transform* New2D() {
		return g_TransformNew2DFnPtr();
	}
	static Transform* New3D() {
		return g_TransformNew3DFnPtr();
	}
};

#endif