//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_RESOURCEMANAGER_H
#define EVOSCRIPTLIB_RESOURCEMANAGER_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "string"

class IResource;

typedef std::function<bool(IResource*)> IResourceDestroyFnPtr;
IResourceDestroyFnPtr g_IResourceDestroyFnPtr;
EXTERN void IResourceDestroyFnPtrSetter(const std::function<bool(IResource*)>& fnPtr) { 
	g_IResourceDestroyFnPtr = fnPtr; 
}

typedef std::function<unsigned int(IResource*)> IResourceGetCountUsesFnPtr;
IResourceGetCountUsesFnPtr g_IResourceGetCountUsesFnPtr;
EXTERN void IResourceGetCountUsesFnPtrSetter(const std::function<unsigned int(IResource*)>& fnPtr) { 
	g_IResourceGetCountUsesFnPtr = fnPtr; 
}

class IResource {
public:
	IResource() = delete;
	~IResource() = default;
	IResource(IResource &) = delete;
	IResource(const IResource &) = delete;
public:
	bool Destroy() {
		return g_IResourceDestroyFnPtr(this);
	}
	unsigned int GetCountUses() {
		return g_IResourceGetCountUsesFnPtr(this);
	}
};

#endif