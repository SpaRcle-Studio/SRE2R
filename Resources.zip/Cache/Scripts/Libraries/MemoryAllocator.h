//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_MEMORY_ALLOCATOR_H
#define EVOSCRIPTLIB_MEMORY_ALLOCATOR_H

#include <memory>

#ifndef ES_EXTERN
	#define ES_EXTERN extern "C" __declspec(dllexport)
#endif

typedef void*(*AllocateMemoryFnPtr)(size_t sz);
typedef void(*FreeMemoryFnPtr)(void* ptr);

AllocateMemoryFnPtr g_allocateMemory = nullptr;
FreeMemoryFnPtr g_freeMemory = nullptr;

ES_EXTERN void SetAllocateMemoryFnPtr(AllocateMemoryFnPtr fn) {
	g_allocateMemory = fn;
}

ES_EXTERN void SetFreeMemoryFnPtr(FreeMemoryFnPtr fn) {
	g_freeMemory = fn;
}

void* ESMemoryAlloc(size_t sz) {
	if (g_allocateMemory) {
		return g_allocateMemory(sz);
	}
	return malloc(sz);
}

void ESMemoryFree(void* ptr) {
	if (g_freeMemory) {
		g_freeMemory(ptr);
	}
	else {
		free(ptr);
	}
}

#endif //EVOSCRIPTLIB__MEMORY_ALLOCATOR_H