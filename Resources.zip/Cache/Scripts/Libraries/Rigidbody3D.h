//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_RIGIDBODY3D_H
#define EVOSCRIPTLIB_RIGIDBODY3D_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/Math/Vector2.h"
#include "Libraries/Math/Vector3.h"

class Rigidbody3D;

typedef std::function<void(Rigidbody3D*, const FVector3& velocity)> Rigidbody3DAddLinearVelocityFnPtr;
Rigidbody3DAddLinearVelocityFnPtr g_Rigidbody3DAddLinearVelocityFnPtr;
EXTERN void Rigidbody3DAddLinearVelocityFnPtrSetter(const std::function<void(Rigidbody3D*, const FVector3& velocity)>& fnPtr) { 
	g_Rigidbody3DAddLinearVelocityFnPtr = fnPtr; 
}

typedef std::function<void(Rigidbody3D*, const FVector3& velocity)> Rigidbody3DAddAngularVelocityFnPtr;
Rigidbody3DAddAngularVelocityFnPtr g_Rigidbody3DAddAngularVelocityFnPtr;
EXTERN void Rigidbody3DAddAngularVelocityFnPtrSetter(const std::function<void(Rigidbody3D*, const FVector3& velocity)>& fnPtr) { 
	g_Rigidbody3DAddAngularVelocityFnPtr = fnPtr; 
}

typedef std::function<void(Rigidbody3D*, const FVector3& velocity)> Rigidbody3DSetLinearVelocityFnPtr;
Rigidbody3DSetLinearVelocityFnPtr g_Rigidbody3DSetLinearVelocityFnPtr;
EXTERN void Rigidbody3DSetLinearVelocityFnPtrSetter(const std::function<void(Rigidbody3D*, const FVector3& velocity)>& fnPtr) { 
	g_Rigidbody3DSetLinearVelocityFnPtr = fnPtr; 
}

typedef std::function<void(Rigidbody3D*, const FVector3& velocity)> Rigidbody3DSetAngularVelocityFnPtr;
Rigidbody3DSetAngularVelocityFnPtr g_Rigidbody3DSetAngularVelocityFnPtr;
EXTERN void Rigidbody3DSetAngularVelocityFnPtrSetter(const std::function<void(Rigidbody3D*, const FVector3& velocity)>& fnPtr) { 
	g_Rigidbody3DSetAngularVelocityFnPtr = fnPtr; 
}

typedef std::function<FVector3(Rigidbody3D*)> Rigidbody3DGetLinearVelocityFnPtr;
Rigidbody3DGetLinearVelocityFnPtr g_Rigidbody3DGetLinearVelocityFnPtr;
EXTERN void Rigidbody3DGetLinearVelocityFnPtrSetter(const std::function<FVector3(Rigidbody3D*)>& fnPtr) { 
	g_Rigidbody3DGetLinearVelocityFnPtr = fnPtr; 
}

typedef std::function<FVector3(Rigidbody3D*)> Rigidbody3DGetAngularVelocityFnPtr;
Rigidbody3DGetAngularVelocityFnPtr g_Rigidbody3DGetAngularVelocityFnPtr;
EXTERN void Rigidbody3DGetAngularVelocityFnPtrSetter(const std::function<FVector3(Rigidbody3D*)>& fnPtr) { 
	g_Rigidbody3DGetAngularVelocityFnPtr = fnPtr; 
}

class Rigidbody3D : public Component {
public:
	Rigidbody3D() = delete;
	~Rigidbody3D() = default;
	Rigidbody3D(Rigidbody3D &) = delete;
	Rigidbody3D(const Rigidbody3D &) = delete;
public:
	void AddLinearVelocity(const FVector3& velocity) {
		return g_Rigidbody3DAddLinearVelocityFnPtr(this, velocity);
	}
	void AddAngularVelocity(const FVector3& velocity) {
		return g_Rigidbody3DAddAngularVelocityFnPtr(this, velocity);
	}
	void SetLinearVelocity(const FVector3& velocity) {
		return g_Rigidbody3DSetLinearVelocityFnPtr(this, velocity);
	}
	void SetAngularVelocity(const FVector3& velocity) {
		return g_Rigidbody3DSetAngularVelocityFnPtr(this, velocity);
	}
	FVector3 GetLinearVelocity() {
		return g_Rigidbody3DGetLinearVelocityFnPtr(this);
	}
	FVector3 GetAngularVelocity() {
		return g_Rigidbody3DGetAngularVelocityFnPtr(this);
	}
};

#endif