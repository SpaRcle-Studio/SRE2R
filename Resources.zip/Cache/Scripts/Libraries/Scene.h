//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_SCENE_H
#define EVOSCRIPTLIB_SCENE_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/GameObject.h"
#include "Libraries/Observer.h"
#include "Libraries/Types/SafePointer.h"
#include "map"
#include "mutex"
#include "set"
#include "stdint.h"
#include "string"
#include "unordered_set"
#include "vector"

class Observer;

class HierarchyElem;
class SceneLogic;
class Scene;
class SceneCubeChunkLogic;

typedef std::function<std::string(Scene*)> SceneGetNameFnPtr;
SceneGetNameFnPtr g_SceneGetNameFnPtr;
EXTERN void SceneGetNameFnPtrSetter(const std::function<std::string(Scene*)>& fnPtr) { 
	g_SceneGetNameFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(Scene*, const std::string& name)> SceneInstanceFnPtr;
SceneInstanceFnPtr g_SceneInstanceFnPtr;
EXTERN void SceneInstanceFnPtrSetter(const std::function<SharedPtr<GameObject>(Scene*, const std::string& name)>& fnPtr) { 
	g_SceneInstanceFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(Scene*, const std::string& name)> SceneInstanceFromFileFnPtr;
SceneInstanceFromFileFnPtr g_SceneInstanceFromFileFnPtr;
EXTERN void SceneInstanceFromFileFnPtrSetter(const std::function<SharedPtr<GameObject>(Scene*, const std::string& name)>& fnPtr) { 
	g_SceneInstanceFromFileFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(Scene*, const std::string& name)> SceneFindByComponentFnPtr;
SceneFindByComponentFnPtr g_SceneFindByComponentFnPtr;
EXTERN void SceneFindByComponentFnPtrSetter(const std::function<SharedPtr<GameObject>(Scene*, const std::string& name)>& fnPtr) { 
	g_SceneFindByComponentFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(Scene*, const std::string& name)> SceneFindFnPtr;
SceneFindFnPtr g_SceneFindFnPtr;
EXTERN void SceneFindFnPtrSetter(const std::function<SharedPtr<GameObject>(Scene*, const std::string& name)>& fnPtr) { 
	g_SceneFindFnPtr = fnPtr; 
}

typedef std::function<SharedPtr<GameObject>(Scene*, const std::string& name)> SceneFindOrInstanceFnPtr;
SceneFindOrInstanceFnPtr g_SceneFindOrInstanceFnPtr;
EXTERN void SceneFindOrInstanceFnPtrSetter(const std::function<SharedPtr<GameObject>(Scene*, const std::string& name)>& fnPtr) { 
	g_SceneFindOrInstanceFnPtr = fnPtr; 
}

typedef std::function<SafePtr<SceneLogic>(Scene*)> SceneGetLogicBaseFnPtr;
SceneGetLogicBaseFnPtr g_SceneGetLogicBaseFnPtr;
EXTERN void SceneGetLogicBaseFnPtrSetter(const std::function<SafePtr<SceneLogic>(Scene*)>& fnPtr) { 
	g_SceneGetLogicBaseFnPtr = fnPtr; 
}

typedef std::function<SafePtr<Scene>(const std::string& name)> SceneNewFnPtr;
SceneNewFnPtr g_SceneNewFnPtr;
EXTERN void SceneNewFnPtrSetter(const std::function<SafePtr<Scene>(const std::string& name)>& fnPtr) { 
	g_SceneNewFnPtr = fnPtr; 
}

typedef std::function<Observer*(SceneCubeChunkLogic*)> SceneCubeChunkLogicGetObserverFnPtr;
SceneCubeChunkLogicGetObserverFnPtr g_SceneCubeChunkLogicGetObserverFnPtr;
EXTERN void SceneCubeChunkLogicGetObserverFnPtrSetter(const std::function<Observer*(SceneCubeChunkLogic*)>& fnPtr) { 
	g_SceneCubeChunkLogicGetObserverFnPtr = fnPtr; 
}

typedef std::function<ESMakePair(IVector3, IVector3)(SceneCubeChunkLogic*, const FVector3& position)> SceneCubeChunkLogicGetRegionAndChunkFnPtr;
SceneCubeChunkLogicGetRegionAndChunkFnPtr g_SceneCubeChunkLogicGetRegionAndChunkFnPtr;
EXTERN void SceneCubeChunkLogicGetRegionAndChunkFnPtrSetter(const std::function<ESMakePair(IVector3, IVector3)(SceneCubeChunkLogic*, const FVector3& position)>& fnPtr) { 
	g_SceneCubeChunkLogicGetRegionAndChunkFnPtr = fnPtr; 
}

typedef std::function<FVector3(SceneCubeChunkLogic*, const IVector3& region, const IVector3& chunk)> SceneCubeChunkLogicGetWorldPositionFnPtr;
SceneCubeChunkLogicGetWorldPositionFnPtr g_SceneCubeChunkLogicGetWorldPositionFnPtr;
EXTERN void SceneCubeChunkLogicGetWorldPositionFnPtrSetter(const std::function<FVector3(SceneCubeChunkLogic*, const IVector3& region, const IVector3& chunk)>& fnPtr) { 
	g_SceneCubeChunkLogicGetWorldPositionFnPtr = fnPtr; 
}

typedef std::function<bool(SceneCubeChunkLogic*, const IVector3& region, const IVector3& chunk)> SceneCubeChunkLogicIsChunkLoadedFnPtr;
SceneCubeChunkLogicIsChunkLoadedFnPtr g_SceneCubeChunkLogicIsChunkLoadedFnPtr;
EXTERN void SceneCubeChunkLogicIsChunkLoadedFnPtrSetter(const std::function<bool(SceneCubeChunkLogic*, const IVector3& region, const IVector3& chunk)>& fnPtr) { 
	g_SceneCubeChunkLogicIsChunkLoadedFnPtr = fnPtr; 
}

typedef std::function<bool(SceneCubeChunkLogic*, int32_t x, int32_t y, int32_t z)> SceneCubeChunkLogicScopeCheckFunctionFnPtr;
SceneCubeChunkLogicScopeCheckFunctionFnPtr g_SceneCubeChunkLogicScopeCheckFunctionFnPtr;
EXTERN void SceneCubeChunkLogicScopeCheckFunctionFnPtrSetter(const std::function<bool(SceneCubeChunkLogic*, int32_t x, int32_t y, int32_t z)>& fnPtr) { 
	g_SceneCubeChunkLogicScopeCheckFunctionFnPtr = fnPtr; 
}

class HierarchyElem {
public:
	HierarchyElem() = delete;
	~HierarchyElem() = default;
	HierarchyElem(HierarchyElem &) = delete;
	HierarchyElem(const HierarchyElem &) = delete;
};

class SceneLogic {
public:
	SceneLogic() = delete;
	~SceneLogic() = default;
	SceneLogic(SceneLogic &) = delete;
	SceneLogic(const SceneLogic &) = delete;
};

class Scene : public SafePtr<Scene> {
public:
	Scene() = delete;
	~Scene() = default;
	Scene(Scene &) = delete;
	Scene(const Scene &) = delete;
public:
	std::string GetName() {
		return g_SceneGetNameFnPtr(this);
	}
	SharedPtr<GameObject> Instance(const std::string& name) {
		return g_SceneInstanceFnPtr(this, name);
	}
	SharedPtr<GameObject> InstanceFromFile(const std::string& name) {
		return g_SceneInstanceFromFileFnPtr(this, name);
	}
	SharedPtr<GameObject> FindByComponent(const std::string& name) {
		return g_SceneFindByComponentFnPtr(this, name);
	}
	SharedPtr<GameObject> Find(const std::string& name) {
		return g_SceneFindFnPtr(this, name);
	}
	SharedPtr<GameObject> FindOrInstance(const std::string& name) {
		return g_SceneFindOrInstanceFnPtr(this, name);
	}
	SafePtr<SceneLogic> GetLogicBase() {
		return g_SceneGetLogicBaseFnPtr(this);
	}
	static SafePtr<Scene> New(const std::string& name) {
		return g_SceneNewFnPtr(name);
	}
};

class SceneCubeChunkLogic {
public:
	SceneCubeChunkLogic() = delete;
	~SceneCubeChunkLogic() = default;
	SceneCubeChunkLogic(SceneCubeChunkLogic &) = delete;
	SceneCubeChunkLogic(const SceneCubeChunkLogic &) = delete;
public:
	Observer* GetObserver() {
		return g_SceneCubeChunkLogicGetObserverFnPtr(this);
	}
	ESMakePair(IVector3, IVector3) GetRegionAndChunk(const FVector3& position) {
		return g_SceneCubeChunkLogicGetRegionAndChunkFnPtr(this, position);
	}
	FVector3 GetWorldPosition(const IVector3& region, const IVector3& chunk) {
		return g_SceneCubeChunkLogicGetWorldPositionFnPtr(this, region, chunk);
	}
	bool IsChunkLoaded(const IVector3& region, const IVector3& chunk) {
		return g_SceneCubeChunkLogicIsChunkLoadedFnPtr(this, region, chunk);
	}
	bool ScopeCheckFunction(int32_t x, int32_t y, int32_t z) {
		return g_SceneCubeChunkLogicScopeCheckFunctionFnPtr(this, x, y, z);
	}
};

#endif