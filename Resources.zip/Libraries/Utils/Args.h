//
// Created by Monika on 05.03.2023.
//

#ifndef EVOSCRIPTLIB_ARGS_H
#define EVOSCRIPTLIB_ARGS_H

#define ESArg1(a1) a1
#define ESArg2(a1, a2) a1, a2
#define ESArg3(a1, a2, a3) a1, a2, a3
#define ESArg4(a1, a2, a3, a4) a1, a2, a3, a4
#define ESArg5(a1, a2, a3, a4, a5) a1, a2, a3, a4, a5
#define ESArg6(a1, a2, a3, a4, a5, a6) a1, a2, a3, a4, a5, a6
#define ESArg7(a1, a2, a3, a4, a5, a6, a7) a1, a2, a3, a4, a5, a6, a7

#endif //EVOSCRIPTLIB_ARGS_H
