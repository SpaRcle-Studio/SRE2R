//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_SKYBOX_H
#define EVOSCRIPTLIB_SKYBOX_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "array"
#include "stdint.h"
#include "string"
#include "vector"

class Skybox;

class Skybox {
public:
	Skybox() = delete;
	~Skybox() = default;
	Skybox(Skybox &) = delete;
	Skybox(const Skybox &) = delete;
};

#endif