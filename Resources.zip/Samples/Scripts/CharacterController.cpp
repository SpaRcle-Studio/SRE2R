//
// Created by Monika on 24.05.2022.
//

#include "CharacterController.h"

REGISTER_BEHAVIOUR(CharacterController)
