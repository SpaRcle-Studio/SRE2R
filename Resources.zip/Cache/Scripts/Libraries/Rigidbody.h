//
// Created by Evo Script code generator on Mon Apr 22 20:46:01 2024 | Author - Monika
//

#ifndef EVOSCRIPTLIB_RIGIDBODY_H
#define EVOSCRIPTLIB_RIGIDBODY_H

#ifndef EXTERN
#define EXTERN extern "C" __declspec(dllexport)
#endif

#include <functional>

#include "Libraries/Component.h"
#include "Libraries/Math/Vector2.h"
#include "Libraries/Math/Vector3.h"

class Rigidbody;

class Rigidbody : public Component {
public:
	Rigidbody() = delete;
	~Rigidbody() = default;
	Rigidbody(Rigidbody &) = delete;
	Rigidbody(const Rigidbody &) = delete;
};

#endif